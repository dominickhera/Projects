#ifndef __DHERA_HOLES__
#define __DHERA_HOLES__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#endif
